package testes;

import controller.daoEditora;
import java.sql.SQLException;
import model.Editora;

public class testeEditora {
    
    public static void main(String[] args) {
        
        daoEditora dao = new daoEditora();
        
        Editora e1 = new Editora(0, "Vida", "39.419.679/0001-93");
        Editora e2 = new Editora(0, "Seguinte", "74.481.672/0001-00");
        Editora e3 = new Editora(0, "Rocco", "14.819.805/0001-76");
        
        try{
            /*dao.create(e1);
            dao.create(e2);
            dao.create(e3);*/
            for (Editora editora : dao.read()) {
                 System.out.println(editora.getId()+"\t"+editora.getNome()+"\t"+editora.getCnpj());
            }
        }catch(SQLException ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
    }
}
