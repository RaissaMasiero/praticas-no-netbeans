package testes;

import controller.daoGenero;
import java.sql.SQLException;
import model.Genero;

public class testeGenero {
    
    public static void main(String[] args) {
        
        daoGenero dao = new daoGenero();
        /*Genero g1 = new Genero(0, "Romance");
        Genero g2 = new Genero(0, "drama");
        Genero g3 = new Genero(0, "comédia");*/
        Genero g5;

        try{
            //g5 = dao.read(7);
            //dao.delete(g5);
            for (Genero genero : dao.read()) {
                 System.out.println(genero.getId()+"\t"+genero.getNome());
            } 
        }catch(SQLException ex){
                System.out.println("ERRO: " + ex.getMessage());    
        }
    }
}
