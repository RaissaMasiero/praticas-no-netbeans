package testes;

import controller.daoLivro;
import java.sql.SQLException;
import model.Livro;

public class testeLivro {
    
    public static void main(String[] args) {
        
        daoLivro dao = new daoLivro();
     
        try{
            for (Livro livro : dao.read()) {
                 System.out.println(livro.getId()+"\t"+livro.getTitulo()+"\t"+livro.getIsbn()+"\t"+
                                    livro.getAutor().getNome()+"\t"+livro.getEditora().getNome()+"\t"+
                                    livro.getGenero().getNome());
            }
        }catch(SQLException ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
            
    }
} 
