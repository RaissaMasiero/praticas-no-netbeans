package testes;

import controller.daoAutor;
import java.sql.SQLException;
import model.Autor;

public class testeAutor {
    
    public static void main(String[] args) {
        
        daoAutor dao = new daoAutor();
        
        Autor a1 = new Autor(0, "Kiera", "000.000.000-00");
        Autor a2 = new Autor(0, "Renan", "010.110.011-11");
        Autor a3 = new Autor(0, "Ivete", "112.021.012-12");
        
        try{
            /*dao.create(a1);
            dao.create(a2);
            dao.create(a3); */
            for (Autor autor : dao.read()) {
                 System.out.println(autor.getId()+"\t"+autor.getNome()+"\t"+autor.getCpf());
            }
        }catch(SQLException ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
    }
    
}
