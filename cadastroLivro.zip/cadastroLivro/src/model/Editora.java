package model;

public class Editora implements java.io.Serializable{
    
    private int id;
    private String nome;
    private String cnpj;
    
    public Editora(){
        this.setId(0);
        this.setNome("padrão");
        this.setCnpj("00.000.000/0000-00");
    }
    
     public Editora(int id, String nome, String cnpj){
        this.setId(id);
        this.setNome(nome);
        this.setCnpj(cnpj);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome.trim().isEmpty()? "padrão" : nome.toUpperCase();
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public int getId() {
        return this.id;
    }

    public String getNome() {
        return this.nome;
    }

    public String getCnpj() {
        return this.cnpj;
    }

    @Override
    public String toString() {
        return this.nome;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Editora other = (Editora) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    } 
}
