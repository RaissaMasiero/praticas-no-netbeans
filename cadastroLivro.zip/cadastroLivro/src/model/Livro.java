package model;

public class Livro implements java.io.Serializable{
    
    private int id;
    private String titulo;
    private String isbn;
    private Autor autor;
    private Editora editora;
    private Genero genero;
    
    public Livro(){
        this.setId(0);
        this.setTitulo("título padrão");
        this.setIsbn("000-00-00000-00-0");
        this.setAutor(null);
        this.setEditora(null);
        this.setGenero(null);
    }
    
    public Livro(int id, String titulo, String isbn, Autor autor, Editora editora, Genero genero){
        this.setId(id);
        this.setTitulo(titulo);
        this.setIsbn(isbn);
        this.setAutor(autor);
        this.setEditora(editora);
        this.setGenero(genero);
    }  

    public void setId(int id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo.trim().isEmpty()? "TÍTULO PADRÃO" : titulo.toUpperCase();
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setAutor(Autor autor) {
        this.autor = autor==null? new Autor() : autor;
    }

    public void setEditora(Editora editora) {
        this.editora = editora==null? new Editora() : editora;
    }

    public void setGenero(Genero genero) {
        this.genero = genero==null? new Genero() : genero;
    }

    public int getId() {
        return this.id;
    }

    public String getTitulo() {
        return this.titulo;
    }

    public String getIsbn() {
        return this.isbn;
    }

    public Autor getAutor() {
        return this.autor;
    }

    public Editora getEditora() {
        return this.editora;
    }

    public Genero getGenero() {
        return this.genero;
    }

    @Override
    public String toString() {
        return this.titulo+"(Autor: "+this.autor+")";
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Livro other = (Livro) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
}
