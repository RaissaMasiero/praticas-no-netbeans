package controller;

import abstratas.dao;
import java.sql.SQLException;
import model.Autor;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class daoAutor extends dao {
    
    public int create(Autor autor) throws SQLException{
        String SQL="INSERT INTO AUTOR (NOME, CPF) VALUES (?, ?)";
        return super.executeUpdate(SQL, autor.getNome(), autor.getCpf());
    }
    
    public int update(Autor autor) throws SQLException{
        String SQL="UPDATE AUTOR SET NOME=?, CPF=? WHERE ID=?";
        return super.executeUpdate(SQL, autor.getNome(), autor.getCpf(), autor.getId());
    }
    
    public int delete(Autor autor) throws SQLException{
        String SQL="DELETE FROM AUTOR WHERE ID="+autor.getId();
        return super.executeUpdate(SQL);
    }
    
    public Autor read(int id) throws SQLException{
        String SQL="SELECT * FROM AUTOR WHERE ID="+id;
        ResultSet rs = super.executeQuery(SQL);
        return (rs.next()? createObject(rs) : null);
    }   

    public List<Autor> read() throws SQLException{
        String SQL="SELECT * FROM AUTOR ORDER BY NOME";
        ResultSet rs = super.executeQuery(SQL);
        List<Autor> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
    
    public List<Autor> read(String filtro) throws SQLException{
        String SQL="SELECT * FROM AUTOR WHERE NOME LIKE ? ORDER BY NOME";
        ResultSet rs = super.executeQuery(SQL, "%"+filtro.toUpperCase()+"%");
        List<Autor> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
    
    private Autor createObject(ResultSet rs) throws SQLException{
         return (new Autor(rs.getInt("ID"), rs.getString("NOME"), rs.getString("CPF")));
    }
        
}
