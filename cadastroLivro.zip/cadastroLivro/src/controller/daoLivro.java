package controller;

import abstratas.dao;
import java.sql.SQLException;
import model.Livro;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class daoLivro extends dao {
    
    public int create(Livro livro) throws SQLException{
        String SQL="INSERT INTO LIVRO (TITULO, ISBN, ID_AUTOR, ID_EDITORA, ID_GENERO) VALUES (?, ?, ?, ?, ?)";
        return super.executeUpdate(SQL, livro.getTitulo(), livro.getIsbn(), livro.getAutor().getId(),
                                        livro.getEditora().getId(), livro.getGenero().getId());
    }
    
    public int update(Livro livro) throws SQLException{
        String SQL="UPDATE LIVRO SET TITULO=?, ISBN=?, ID_AUTOR=?, ID_EDITORA=?, ID_GENERO=? WHERE ID=?";
        return super.executeUpdate(SQL, livro.getTitulo(), livro.getIsbn(), livro.getAutor().getId(),
                                        livro.getEditora().getId(), livro.getGenero().getId(), livro.getId());
    }
    
    public int delete(Livro livro) throws SQLException{
        String SQL="DELETE FROM LIVRO WHERE ID="+livro.getId();
        return super.executeUpdate(SQL);
    }
    
    public Livro read(int id) throws SQLException{
        String SQL="SELECT * FROM LIVRO WHERE ID="+id;
        ResultSet rs = super.executeQuery(SQL);
        return (rs.next()? createObject(rs) : null);
    }
    
    public List<Livro> read() throws SQLException{
        String SQL="SELECT * FROM LIVRO ORDER BY TITULO";
        ResultSet rs = super.executeQuery(SQL);
        List<Livro> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }

    public List<Livro> read(String filtro) throws SQLException{
        String SQL="SELECT * FROM LIVRO WHERE TITULO LIKE ? ORDER BY TITULO";
        ResultSet rs = super.executeQuery(SQL, "%"+filtro.toUpperCase()+"%");
        List<Livro> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
    
    private Livro createObject(ResultSet rs) throws SQLException{
         return (new Livro(rs.getInt("ID"),
                 rs.getString("TITULO"),
                 rs.getString("ISBN"),
                 new daoAutor().read(rs.getInt("ID_AUTOR")),
                 new daoEditora().read(rs.getInt("ID_EDITORA")),
                 new daoGenero().read(rs.getInt("ID_GENERO"))
         ));
    }
}
    
