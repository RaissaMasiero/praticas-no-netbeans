package controller;

import abstratas.dao;
import java.sql.SQLException;
import model.Editora;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class daoEditora extends dao {
    
    public int create(Editora editora) throws SQLException{
        String SQL="INSERT INTO EDITORA (NOME, CNPJ) VALUES (?, ?)";
        return super.executeUpdate(SQL, editora.getNome(), editora.getCnpj());
    }
    
     public int update(Editora editora) throws SQLException{
         String SQL="UPDATE EDITORA SET NOME=?, CNPJ=? WHERE ID=?";
         return super.executeUpdate(SQL, editora.getNome(), editora.getCnpj(), editora.getId());
     }
     
     public int delete(Editora editora) throws SQLException{
         return super.executeUpdate("DELETE FROM EDITORA WHERE ID="+editora.getId());
     }
     
     public Editora read(int id) throws SQLException{
         String SQL="SELECT * FROM EDITORA WHERE ID="+id;
         ResultSet rs = super.executeQuery(SQL);
         return (rs.next()? createObject(rs) : null);
     }
     
     public List<Editora> read() throws SQLException{
        String SQL="SELECT * FROM EDITORA ORDER BY NOME";
        ResultSet rs = super.executeQuery(SQL);
        List<Editora> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
     
    public List<Editora> read(String filtro) throws SQLException{
        String SQL="SELECT * FROM EDITORA WHERE NOME LIKE ? ORDER BY NOME";
        ResultSet rs = super.executeQuery(SQL, "%"+filtro.toUpperCase()+"%");
        List<Editora> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
     
    private Editora createObject(ResultSet rs) throws SQLException{
         return (new Editora(rs.getInt("ID"), rs.getString("NOME"), rs.getString("CNPJ")));
    }
}
