package controller;

import abstratas.dao;
import java.sql.SQLException;
import model.Genero;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class daoGenero extends dao{
    
    public int create(Genero genero) throws SQLException{
        String SQL="INSERT INTO GENERO (NOME) VALUES (?)";
        return super.executeUpdate(SQL, genero.getNome());
    }
    
    public int update(Genero genero) throws SQLException{
        String SQL="UPDATE GENERO SET NOME=? WHERE ID=?";
        return super.executeUpdate(SQL, genero.getNome(), genero.getId());
    }
    
     public int delete(Genero genero) throws SQLException{
         return super.executeUpdate("DELETE FROM GENERO WHERE ID="+genero.getId());
     }
     
     public Genero read(int id) throws SQLException{
         String SQL="SELECT * FROM GENERO WHERE ID="+id;
         ResultSet rs = super.executeQuery(SQL);
         return (rs.next()? createObject(rs) : null);
     }
     
     public List<Genero> read() throws SQLException{
         String SQL="SELECT * FROM GENERO ORDER BY NOME";
         ResultSet rs = super.executeQuery(SQL);
         List<Genero> retorno = new LinkedList<>();
         while(rs.next()){
             retorno.add(createObject(rs));
         }
         return retorno;
     }
     
     public List<Genero> read(String filtro) throws SQLException{
         String SQL="SELECT * FROM GENERO WHERE NOME LIKE ? ORDER BY NOME";
         ResultSet rs = super.executeQuery(SQL, "%"+filtro.toUpperCase()+"%");
         List<Genero> retorno = new LinkedList<>();
         while(rs.next()){
             retorno.add(createObject(rs));
         }
         return retorno;
     }
     
     private Genero createObject(ResultSet rs) throws SQLException{
         return (new Genero(rs.getInt("ID"), rs.getString("NOME")));
     }
}
