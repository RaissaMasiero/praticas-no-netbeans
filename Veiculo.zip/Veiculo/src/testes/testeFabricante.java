package testes;

import controller.daoFabricante;
import model.Fabricante;

public class testeFabricante {
    
    public static void main(String[] args) {
     
        daoFabricante dao = new daoFabricante();
        
        Fabricante f1 = new Fabricante(0, "General Motors");
        Fabricante f2 = new Fabricante(0, "VOlkswagen");
        Fabricante f3 = new Fabricante(0, "Toyota");
        
        try{
            /*dao.create(f1);
            dao.create(f2);
            dao.create(f3); */

            for(Fabricante fabricante : dao.read()){
                System.out.println(fabricante.getId()+"\t"+fabricante.getNome());
            }
        }catch(Exception ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
    }
    
}
