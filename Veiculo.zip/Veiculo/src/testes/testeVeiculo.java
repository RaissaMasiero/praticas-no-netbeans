package testes;

import controller.daoFabricante;
import controller.daoVeiculo;
import java.time.LocalDate;
import model.Fabricante;
import model.Veiculo;

public class testeVeiculo {
    
    public static void main(String[] args) {
        
        daoVeiculo dao = new daoVeiculo();
        
        Veiculo v1 = new Veiculo(0, "MJN-4347", LocalDate.now(), 110, 500.00, 
                                    new daoFabricante().read(Fabricante.class, 1));
        
        Veiculo v2 = new Veiculo(0, "KLJ-900", LocalDate.now(), 112, 400.00, 
                                    new daoFabricante().read(Fabricante.class, 2));
         
        Veiculo v3 = new Veiculo(0, "SDS-3433", LocalDate.now(), 0, 600.00, 
                                    new daoFabricante().read(Fabricante.class, 3));
        
        try{
            /*dao.create(v1);
            dao.create(v2);
            dao.create(v3); */
            
            for(Veiculo veiculo : dao.read()){
                System.out.println(veiculo.getId()+"\t"+veiculo.getPlaca()+"\t"+veiculo.getDataCompra()+"\t"+
                        veiculo.getOdometro()+"\t"+veiculo.getPreco()+"\t"+veiculo.getFabricante());
            }
        }catch(Exception ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
        
    }
    
}
