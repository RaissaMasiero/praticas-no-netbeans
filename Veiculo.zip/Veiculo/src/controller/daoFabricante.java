package controller;

import abstratas.dao;
import java.util.List;
import model.Fabricante;

public class daoFabricante extends dao<Fabricante> {
    
    public List<Fabricante> read(){
        return (super.read("select f from Fabricante f order by f.nome"));
    }
    
     public List<Fabricante> read(String filtro){
        return (super.read("select f from Fabricante f where f.nome like ?1 order by f.nome", "%"+filtro.toUpperCase()+"%"));
    }
}
