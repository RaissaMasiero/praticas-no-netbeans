package controller;

import abstratas.dao;
import java.util.List;
import model.Fabricante;
import model.Veiculo;

public class daoVeiculo extends dao<Veiculo> {
    
    public List<Veiculo> read(){
        return (super.read("select v from Veiculo v order by v.id"));
    }
    
    public List<Veiculo> read(String filtro){
        return (super.read("select v from Veiculo v where v.dataCompra like ?1 order by v.id", 
                            "%"+filtro.toUpperCase()+"%"));
    }
    
    public List<Veiculo> read(Fabricante fabricante){
        return (super.read("select v from Veiculo v where v.fabricante = ?1 order by v.id", fabricante));
    }
}
