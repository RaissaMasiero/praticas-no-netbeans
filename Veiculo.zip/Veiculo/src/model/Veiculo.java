package model;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VEICULOS")

public class Veiculo implements java.io.Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false)
    private int id;
    
    @Column(name = "PLACA", nullable = false, length = 10)
    private String placa;
    
    @Column(name = "DATACOMPRA", nullable = false)
    private LocalDate dataCompra;
    
    @Column(name = "ODOMETRO", nullable = false)
    private int odometro;
    
    @Column(name = "PRECO", nullable = false, scale = 2)
    private double preco;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_FABRICANTE", nullable = false, referencedColumnName = "ID")
    private Fabricante fabricante;

    public Veiculo() {
        this.setId(0);
        this.setPlaca("");
        this.setDataCompra(null);
        this.setOdometro(0);
        this.setPreco(0.0);
        this.setFabricante(null);
    }
    
    public Veiculo(int id, String placa, LocalDate dataCompra, int odometro, double preco, Fabricante fabricante) {
        this.setId(id);
        this.setPlaca(placa);
        this.setDataCompra(dataCompra);
        this.setOdometro(odometro);
        this.setPreco(preco);
        this.setFabricante(fabricante);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPlaca(String placa) {
        this.placa = placa.trim().isEmpty()? "PLACA PADRÃO" : placa.toUpperCase();
    }

    public void setDataCompra(LocalDate dataCompra) {
        this.dataCompra = dataCompra == null ? LocalDate.now() : dataCompra;
    }

    public void setOdometro(int odometro) {
        this.odometro = odometro < 0 ? 0 : odometro;
    }

    public void setPreco(double preco) {
        this.preco = preco < 0 ? 0 : preco;
    }

    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante == null ? new Fabricante() : fabricante;
    }

    public int getId() {
        return this.id;
    }

    public String getPlaca() {
        return this.placa;
    }

    public LocalDate getDataCompra() {
        return this.dataCompra;
    }

    public int getOdometro() {
        return this.odometro;
    }

    public double getPreco() {
        return this.preco;
    }

    public Fabricante getFabricante() {
        return this.fabricante;
    }

    @Override
    public String toString() {
        return this.placa;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Veiculo other = (Veiculo) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
}
