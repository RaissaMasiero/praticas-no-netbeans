package abstratas;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

abstract public class conexao {
    
    private static EntityManager entity = null;
    
    public static EntityManager getEntity(){
        
        if(entity == null){
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("VeiculoPU");
            entity = factory.createEntityManager();
        }
        
        return entity;
    }
}
