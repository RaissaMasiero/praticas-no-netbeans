package classes;

import abstratas.Base;

public class Peca extends Base {
    
    private String referencia;
    private Equipamento equipamento;
    private boolean permiteVenda;
    private double valorCusto;

    public Peca() {
        super();
        this.setReferencia("");
        this.setEquipamento(null);
        this.setPermiteVenda(true);
        this.setValorCusto(0.1);
    }

    public Peca(String nome, String referencia, Equipamento equipamento, boolean permiteVenda, double valorCusto) {
        super(nome);
        this.setReferencia(referencia);
        this.setEquipamento(equipamento);
        this.setPermiteVenda(permiteVenda);
        this.setValorCusto(valorCusto);
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia.trim().isEmpty()? "REFERÊNCIA PADRÃO" : referencia;
    }

    public void setEquipamento(Equipamento equipamento) {
        this.equipamento = equipamento == null? new Equipamento() : equipamento;
    }

    public void setPermiteVenda(boolean permiteVenda) {
        this.permiteVenda = permiteVenda;
    }

    public void setValorCusto(double valorCusto) {
        this.valorCusto = valorCusto < 0? 0.1 : valorCusto;
    }

    public String getReferencia() {
        return this.referencia;
    }

    public Equipamento getEquipamento() {
        return this.equipamento;
    }

    public boolean isPermiteVenda() {
        return this.permiteVenda;
    }

    public double getValorCusto() {
        return this.valorCusto;
    }

    @Override
    public String toString() {
        return super.getNome() + "(" + this.equipamento + ")";
    }
}
