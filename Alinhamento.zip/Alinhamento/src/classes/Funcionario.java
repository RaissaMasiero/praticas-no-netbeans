package classes;

import abstratas.Base;
import enums.Qualificacoes;

public class Funcionario extends Base {
    
    private String cpf;
    private int idade;
    private Setor setor;
    private Qualificacoes qualificacao;

    public Funcionario() {
        super();
        this.setCpf("");
        this.setIdade(18);
        this.setSetor(null);
        this.setQualificacao(Qualificacoes.A);
    }

    public Funcionario(String nome, String cpf, int idade, Setor setor, Qualificacoes qualificacao) {
        super(nome);
        this.setCpf(cpf);
        this.setIdade(idade);
        this.setSetor(setor);
        this.setQualificacao(qualificacao);
    }

    public void setCpf(String cpf) {
        this.cpf = cpf.trim().isEmpty()? "000.000.000-00" : cpf;
    }

    public void setIdade(int idade) {
        this.idade = idade < 0 || idade > 120? 18 : idade;
    }

    public void setSetor(Setor setor) {
        this.setor = setor == null? new Setor() : setor;
    }

    public void setQualificacao(Qualificacoes qualificacao) {
        this.qualificacao = qualificacao == null? Qualificacoes.A : qualificacao;
    }

    public String getCpf() {
        return this.cpf;
    }

    public int getIdade() {
        return this.idade;
    }

    public Setor getSetor() {
        return this.setor;
    }

    public Qualificacoes getQualificacao() {
        return this.qualificacao;
    }

    @Override
    public String toString() {
        return super.getNome() + "(" + this.cpf + ")";
    }
}
