package classes;

import enums.Tipos;

public class Equipamento {
    
    private int numero;
    private Tipos tipo;
    private Funcionario funcionario;
    
    public Equipamento() {
        this.setNumero(999);
        this.setTipo(Tipos.P);
        this.setFuncionario(null);
    }    

    public Equipamento(int numero, Tipos tipo, Funcionario funcionario) {
        this.setNumero(numero);
        this.setTipo(tipo);
        this.setFuncionario(funcionario);
    }

    public void setNumero(int numero) {
        this.numero = numero < 0? 999 : numero;
    }

    public void setTipo(Tipos tipo) {
        this.tipo = tipo == null? Tipos.P : tipo;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario == null? new Funcionario() : funcionario;
    }

    public int getNumero() {
        return this.numero;
    }

    public Tipos getTipo() {
        return this.tipo;
    }

    public Funcionario getFuncionario() {
        return this.funcionario;
    }

    @Override
    public String toString() {
        return this.numero+"";
    }
}
