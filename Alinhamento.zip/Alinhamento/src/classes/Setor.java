package classes;

import abstratas.Base;

public class Setor extends Base {
    
    public Setor() {
        super();
    }

    public Setor(String nome) {
        super(nome);
    }
    
    // a única coisa que não vem da herança são os construtores.
}
