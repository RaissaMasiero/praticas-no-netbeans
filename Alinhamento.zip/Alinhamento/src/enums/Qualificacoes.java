package enums;

public enum Qualificacoes {
    
    A ("Aprendiz"), 
    J ("Júnior"), 
    S ("Sênior"),
    P ("Pleno");
    
    private String descricao;

    private Qualificacoes(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
