package enums;

public enum Tipos {
    
    T ("Torno"),
    P ("Prensa"),
    S ("Solda");
    
    private String descricao;

    private Tipos(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
