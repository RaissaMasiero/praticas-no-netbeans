package abstratas;

import classes.Equipamento;
import classes.Funcionario;
import classes.Peca;
import classes.Setor;
import java.util.LinkedList;

abstract public class Dados {
    
    private static LinkedList<Setor> listaSetor = new LinkedList<>();
    private static LinkedList<Funcionario> listaFuncionario = new LinkedList<>();
    private static LinkedList<Equipamento> listaEquipamento = new LinkedList<>();
    private static LinkedList<Peca> listaPeca = new LinkedList<>();

    public static LinkedList<Setor> getListaSetor() {
        return listaSetor;
    }

    public static LinkedList<Funcionario> getListaFuncionario() {
        return listaFuncionario;
    }

    public static LinkedList<Equipamento> getListaEquipamento() {
        return listaEquipamento;
    }
    
    public static LinkedList<Peca> getListaPeca () {
        return listaPeca;
    }    
}
