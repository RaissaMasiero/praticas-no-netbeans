
package enums;

public enum Unidades {
    UND,
    KG,
    LT,
    MT,
    CX,
    PAR,
    KIT,
    PCT,
    MIL,
    TON;
}
