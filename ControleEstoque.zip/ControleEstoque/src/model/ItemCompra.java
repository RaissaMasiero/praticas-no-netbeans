
package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ITEMSCOMPRA")

public class ItemCompra implements java.io.Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID",nullable = false)
    @SwingColumn(description = "Número")
    private int id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_COMPRA",nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "Compra")
    private Compra compra;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_PRODUTO",nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "Produto")
    private Produto produto;
    
    @Column(name = "QUANTIDADE",nullable = false,scale = 2)
    @SwingColumn(description = "Qtde")
    private double quantidade;

    @Column(name = "PRECO",nullable = false,scale = 2)
    @SwingColumn(description = "Preço")
    private double preco;
    
    @SwingColumn(description = "Total")
    private double total;

    public ItemCompra() {
    }

    public ItemCompra(int id, Compra compra, Produto produto, double quantidade, double preco) {
        this.setId(id);
        this.setCompra(compra);
        this.setProduto(produto);
        this.setQuantidade(quantidade);
        this.setPreco(preco);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade < 0 ? 0 : quantidade;
    }

    public void setPreco(double preco) {
        this.preco = preco < 0 ? 0 : preco;
    }

    public int getId() {
        return this.id;
    }

    public Compra getCompra() {
        return this.compra;
    }

    public Produto getProduto() {
        return this.produto;
    }

    public double getQuantidade() {
        return this.quantidade;
    }

    public double getPreco() {
        return this.preco;
    }

    public double getTotal() {
        return (this.quantidade*this.preco);
    }

    @Override
    public String toString() {
        return "ItemCompra{" + "compra=" + compra + ", produto=" + produto + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemCompra other = (ItemCompra) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
}
