
package model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "FORNECEDORES")

public class Fornecedor implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false)
    private int id;
    
    @Column(name = "NOME", length = 150, nullable = false)
    private String nome;
    
    @Column(name = "CNPJ", nullable = false, length = 18)
    private String cnpj;
    
    @Column(name = "EMAIL", length = 200, nullable = false)
    private String email;
    
    @Column(name = "REPRESENTANTE", length = 150)
    private String representante;
    
    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CIDADE", nullable = false, referencedColumnName = "ID")
    private Cidade cidade;
    //

    public Fornecedor() {
        this.setId(0);
        this.setNome("");
        this.setCnpj("");
        this.setEmail("");
        this.setRepresentante("");
        this.setCidade(new Cidade());    
    }

    public Fornecedor(int id, String nome, String cnpj, String email, String representante, Cidade cidade) {
        this.setId(id);
        this.setNome(nome);
        this.setCnpj(cnpj);
        this.setEmail(email);
        this.setRepresentante(representante);
        this.setCidade(cidade);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome.trim().isEmpty() ? "NOME PADRÃO" : nome.toUpperCase();
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj.trim().isEmpty()?"00.000.000/0000-00":cnpj;
    }

    public void setEmail(String email) {
        this.email = email.trim().isEmpty() ? "email" : email;
    }

    public void setRepresentante(String representante) {
        this.representante = representante.toUpperCase();
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }
    //
    public int getId() {
        return this.id;
    }

    public String getNome() {
        return this.nome;
    }

    public String getCnpj() {
        return this.cnpj;
    }

    public String getEmail() {
        return this.email;
    }

    public String getRepresentante() {
        return this.representante;
    }

    public Cidade getCidade() {
        return this.cidade;
    }
    //
    @Override
    public String toString() {
        return nome;
    }    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Fornecedor other = (Fornecedor) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
}
