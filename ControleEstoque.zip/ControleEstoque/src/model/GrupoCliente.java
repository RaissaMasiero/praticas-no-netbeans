package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GRUPOCLIENTES")

public class GrupoCliente implements java.io.Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID",nullable = false)
    private int id;
    @Column(name = "NOME",nullable = false,length = 100)
    private String nome;
    @Column(name = "DESCONTO",nullable = false,scale = 2)
    private double percentualDesconto;

    public GrupoCliente() {
        this.setId(0);
        this.setNome("grupo padrão");
        this.setPercentualDesconto(0);
    }

    public GrupoCliente(int id, String nome, double percentualDesconto) {
        this.setId(id);
        this.setNome(nome);
        this.setPercentualDesconto(percentualDesconto);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome.trim().isEmpty() ? "GRUPO PADRÃO" : nome.toUpperCase();
    }

    public void setPercentualDesconto(double percentualDesconto) {
        this.percentualDesconto = percentualDesconto < 0 || percentualDesconto > 100 ? 0 : percentualDesconto;
    }

    public int getId() {
        return this.id;
    }

    public String getNome() {
        return this.nome;
    }

    public double getPercentualDesconto() {
        return this.percentualDesconto;
    }

    @Override
    public String toString() {
        return nome;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GrupoCliente other = (GrupoCliente) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
    
}
