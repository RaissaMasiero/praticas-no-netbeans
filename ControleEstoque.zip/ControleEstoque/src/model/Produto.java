
package model;

import enums.Unidades;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUTOS")

public class Produto implements java.io.Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false)
    @SwingColumn(description = "Código")
    private int id;
    
    @Column(name = "NOME",nullable = false,length = 150)
    @SwingColumn(description = "Nome")
    private String nome;
    
    @Column(name = "UNIDADE",length = 3, nullable = false)
    @Enumerated(EnumType.STRING)
    @SwingColumn(description = "Unid")
    private Unidades unidade; 
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CATEGORIA",nullable = false,referencedColumnName = "ID")
    private CategoriaProduto categoria;
    
    @Column(name = "ESTOQUE", nullable = false, scale = 2)
    @SwingColumn(description = "Estoque")
    private double estoque; 
    
    @Column(name = "CUSTO", nullable = false, scale = 2)
    private double custo; 

    @Column(name = "VENDA", nullable = false, scale = 2)
    @SwingColumn(description = "Venda(R$)")
    private double venda;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_FORNECEDOR",nullable = false,referencedColumnName = "ID")    
    private Fornecedor fornecedor;

    @Column(name = "ATIVO",nullable = false)
    private boolean ativo;
    //
    public Produto() {
    }
    public Produto(int id, String nome, Unidades unidade, CategoriaProduto categoria, double estoque, double custo, double venda, Fornecedor fornecedor, boolean ativo) {
        this.setId(id);
        this.setNome(nome);
        this.setUnidade(unidade);
        this.setCategoria(categoria);
        this.setEstoque(estoque);
        this.setCusto(custo);
        this.setVenda(venda);
        this.setFornecedor(fornecedor);
        this.setAtivo(ativo);
    }
    //
    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome.trim().isEmpty() ? "NOME PRODUTO" : nome.toUpperCase();
    }

    public void setUnidade(Unidades unidade) {
        this.unidade = unidade;
    }

    public void setCategoria(CategoriaProduto categoria) {
        this.categoria = categoria;
    }

    public void setEstoque(double estoque) {
        this.estoque = estoque;
    }

    public void setCusto(double custo) {
        this.custo = custo < 0 ? 0 : custo;
    }

    public void setVenda(double venda) {
        this.venda = venda <= 0 ? 0.01 : venda;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    //

    public int getId() {
        return this.id;
    }

    public String getNome() {
        return this.nome;
    }

    public Unidades getUnidade() {
        return this.unidade;
    }

    public CategoriaProduto getCategoria() {
        return this.categoria;
    }

    public double getEstoque() {
        return this.estoque;
    }

    public double getCusto() {
        return this.custo;
    }

    public double getVenda() {
        return this.venda;
    }

    public Fornecedor getFornecedor() {
        return this.fornecedor;
    }

    public boolean isAtivo() {
        return this.ativo;
    }
    //
    @Override
    public String toString() {
        return nome;
    }
    //
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
    
}
