
package model;

import enums.Sexos;
import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CLIENTES")

public class Cliente implements java.io.Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID",nullable = false)
    @SwingColumn(description = "Código")
    private int id;
    
    @Column(name = "NOME",nullable = false, length = 150)
    @SwingColumn(description = "Nome")
    private String nome;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "SEXO",nullable = false,length = 1)
    private Sexos sexo;
    
    //@Temporal(TemporalType.DATE)
    @Column(name = "NASCIMENTO",nullable = false)
    private LocalDate nascimento;
    
    @Column(name = "CPF", nullable = false, length = 15)
    @SwingColumn(description = "C.P.F.")
    private String cpf;
    
    @Column(name = "ENDERECO", nullable = false, length = 200)
    private String endereco;
    
    @Column(name = "CONTATO", length = 50)
    private String contato;
    
    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CIDADE", nullable = false,referencedColumnName = "ID")
    private Cidade cidade;

    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_GRUPO", nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "Grupo")
    private GrupoCliente grupo;
    //
    public Cliente() {
        this.setId(0);
        this.setNome("nome padrão");
        this.setSexo(Sexos.F);
        this.setNascimento(LocalDate.now());
        this.setCpf("000.000.000-00");
        this.setEndereco("sem endereço");
        this.setContato("");
        this.setCidade(new Cidade());
        this.setGrupo(new GrupoCliente());        
    }
    public Cliente(int id, String nome, Sexos sexo, LocalDate nascimento, String cpf, String endereco, String contato, Cidade cidade, GrupoCliente grupo) {
        this.setId(id);
        this.setNome(nome);
        this.setSexo(sexo);
        this.setNascimento(nascimento);
        this.setCpf(cpf);
        this.setEndereco(endereco);
        this.setContato(contato);
        this.setCidade(cidade);
        this.setGrupo(grupo); 
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setNome(String nome) {
        this.nome = nome.trim().isEmpty() ? "NOME PADRÃO" : nome.toUpperCase();
    }
    public void setSexo(Sexos sexo) {
        this.sexo = sexo;
    }
    public void setNascimento(LocalDate nascimento) {
        this.nascimento = nascimento==null ? LocalDate.now() : nascimento;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco.trim().isEmpty() ? "SEM ENDEREÇO" : endereco.toUpperCase();
    }
    public void setContato(String contato) {
        this.contato = contato.toUpperCase();
    }
    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }
    public void setGrupo(GrupoCliente grupo) {
        this.grupo = grupo;
    }    
    //
    public int getId() {
        return this.id;
    }
    public String getNome() {
        return this.nome;
    }
    public Sexos getSexo() {
        return this.sexo;
    }
    public LocalDate getNascimento() {
        return this.nascimento;
    }
    public String getCpf() {
        return this.cpf;
    }
    public String getEndereco() {
        return this.endereco;
    }
    public String getContato() {
        return this.contato;
    }
    public Cidade getCidade() {
        return this.cidade;
    }
    public GrupoCliente getGrupo() {
        return this.grupo;
    }
    //
    @Override
    public String toString() {
        return nome;
    }
    //
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.id;
        return hash;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
}
