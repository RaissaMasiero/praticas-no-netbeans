
package model;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "COMPRAS")

public class Compra implements java.io.Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID",nullable = false)
    @SwingColumn(description = "Número")
    private int id;
    
    @Column(name = "DATA",nullable = false)
    @SwingColumn(description = "Data")
    private LocalDate data;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_FORNECEDOR",nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "Fornecedor")
    private Fornecedor fornecedor;
    
    @Column(name = "TOTAL",nullable = false,scale = 2)
    @SwingColumn(description = "Total")    
    private double total;
    
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "compra")
    private List<ItemCompra> lista;

    public Compra() {
    }

    public Compra(int id, LocalDate data, Fornecedor fornecedor, double total) {
        this.setId(id);
        this.setData(data);
        this.setFornecedor(fornecedor);
        this.setTotal(total);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setData(LocalDate data) {
        this.data = data==null ? LocalDate.now() : data;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public void setTotal(double total) {
        this.total = total < 0 ? 0 : total;
    }

    public int getId() {
        return this.id;
    }

    public LocalDate getData() {
        return this.data;
    }

    public Fornecedor getFornecedor() {
        return this.fornecedor;
    }

    public double getTotal() {
        return this.total;
    }

    public List<ItemCompra> getLista() {
        return this.lista;
    }
    
    @Override
    public String toString(){
        return this.fornecedor + "(" + this.id + ")";
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Compra other = (Compra) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
}
