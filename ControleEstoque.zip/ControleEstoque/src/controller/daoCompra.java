
package controller;

import abstratas.dao;
import java.util.List;
import model.Compra;
import model.Fornecedor;

public class daoCompra extends dao<Compra>{
    public List<Compra> read(){
        return super.read("select c from Compra c order by c.id");
    }
    public List<Compra> read(Fornecedor fornecedor){
        return super.read("select c from Compra c "
                        + "where c.fornecedor = ?1", fornecedor);
    }
}
