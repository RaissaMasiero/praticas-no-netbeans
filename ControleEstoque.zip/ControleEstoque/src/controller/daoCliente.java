
package controller;

import abstratas.dao;
import enums.Estados;
import java.util.List;
import model.Cliente;
import model.GrupoCliente;

public class daoCliente extends dao<Cliente>{
    public List<Cliente> read(){
        return super.read("select c from Cliente c order by c.nome");
    }    
    public List<Cliente> read(String filtro){
        return super.read("select c from Cliente c where c.nome like ?1 "
                + "order by c.nome",
                "%"+filtro.toUpperCase()+"%");
    }    
    public List<Cliente> read(GrupoCliente grupo){
        return super.read("select c from Cliente c where c.grupo = ?1 "
                + "order by c.nome",
                grupo);
    }        
    public List<Cliente> read(Estados estado){
        return super.read("select c from Cliente c where c.cidade.estado = ?1 "
                + "order by c.nome",
                estado);
    }    
}
