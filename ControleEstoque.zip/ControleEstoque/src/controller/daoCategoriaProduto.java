
package controller;

import abstratas.dao;
import java.util.List;
import model.CategoriaProduto;

public class daoCategoriaProduto extends dao<CategoriaProduto>{

    public List<CategoriaProduto> read(){
        //String SQL="SELECT * FROM CATEGORIASPRODUTO ORDER BY NOME";
        return super.read("select c from CategoriaProduto c order by c.nome");
    }
    public List<CategoriaProduto> read(String filtro){        
        return super.read(
        "select c from CategoriaProduto c where c.nome like ?1 order by c.nome", 
                "%"+filtro.toUpperCase()+"%");
  
    }
}
