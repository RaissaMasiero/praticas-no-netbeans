
package controller;

import abstratas.dao;
import java.time.LocalDate;
import java.util.List;
import model.Compra;
import model.ItemCompra;
import model.Produto;

public class daoItemCompra extends dao<ItemCompra> {
    public List<ItemCompra> read(Compra compra){
        return super.read("select i from ItemCompra i "
                + "where i.compra = ?1", compra);
    }
    public List<ItemCompra> read(Produto produto){
        return super.read("select i from ItemCompra i "
                + "where i.produto = ?1", produto);
    }
    public List<ItemCompra> read(LocalDate datainicial, LocalDate datafinal){
        return super.read("select i from ItemCompra i "
                + "where i.compra.data between ?1 and ?2 "
                + "order by i.compra.data", datainicial,datafinal);
    }    
}
