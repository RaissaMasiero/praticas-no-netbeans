
package controller;

import abstratas.dao;
import java.util.List;
import model.GrupoCliente;

public class daoGrupoCliente extends dao<GrupoCliente>{
    public List<GrupoCliente> read(){
        return super.read("select gc from GrupoCliente gc order by gc.nome");
    }
    public List<GrupoCliente> read(String filtro){
        return super.read("select gc from GrupoCliente gc where gc.nome like ?1 order by gc.nome",
                "%"+filtro.toUpperCase()+"%");        
    }  
}
