
package testes;

import controller.daoCidade;
import controller.daoFornecedor;
import enums.Estados;
import model.Cidade;
import model.Fornecedor;

public class testeFornecedor {
    public static void main(String[] args) {
        Fornecedor f1 = new Fornecedor(
                0, 
                "teste fornecedor 1", 
                "00.000.000/0000-00", 
                "email@hotmail.com", 
                "", 
                new daoCidade().read(Cidade.class, 1));
        Fornecedor f2 = new Fornecedor(
                0, 
                "fornecedor teste 2", 
                "11.111.111/1111-11", 
                "email@gmail.com", 
                "zeca", 
                new daoCidade().read(Cidade.class, 2));
        Fornecedor f3 = new Fornecedor(
                0, 
                "fornece de tudo", 
                "22.222.222/2222-22", 
                "outroemail@hotmail.com", 
                "juca", 
                new daoCidade().read(Cidade.class, 3));
        Fornecedor f4 = new Fornecedor(
                0, 
                "fornece s.a.", 
                "33.333.333/3333-33", 
                "email@hotmail.com", 
                "", 
                new daoCidade().read(Cidade.class, 1));
       
        
        
        daoFornecedor dao = new daoFornecedor();
        //
        dao.create(f1);
        dao.create(f2);
        dao.create(f3);
        dao.create(f4);
        
    }
    
}
