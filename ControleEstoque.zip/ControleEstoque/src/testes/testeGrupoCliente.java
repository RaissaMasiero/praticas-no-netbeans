package testes;

import controller.daoGrupoCliente;
import model.GrupoCliente;

public class testeGrupoCliente {
    public static void main(String[] args) {
        
        GrupoCliente gc1 = new GrupoCliente(0, "cliente bom", 0);
        GrupoCliente gc2 = new GrupoCliente(0, "cliente padrão", 2);
        GrupoCliente gc3 = new GrupoCliente(0, "cliente ótimo", 5);

        daoGrupoCliente dao = new daoGrupoCliente();

        dao.create(gc1);
        dao.create(gc2);
        dao.create(gc3);
        
        for (GrupoCliente cidade : dao.read()){
            System.out.println(cidade.getId()+"\t"+
                    cidade.getNome()+"\t"+
                    cidade.getPercentualDesconto());
        }    
    }
}
