
package testes;

import controller.daoCidade;
import enums.Estados;
import model.Cidade;

public class testeCidade {
    public static void main(String[] args) {
 
        Cidade c1 = new Cidade(0, "porto alegre", Estados.RS);
        Cidade c2 = new Cidade(0, "criciuma", Estados.RS);
        Cidade c3 = new Cidade(0, "curitiba", Estados.PR);

        daoCidade dao = new daoCidade();
        /*
        dao.create(c1);
        dao.create(c2);
        dao.create(c3);
        c2 = dao.read(Cidade.class, 2);
        if (c2 == null){
            System.out.println("Não Localizado");
        }else{
            c2.setEstado(Estados.SC);
            dao.update(c2);
        }
        */
        
        for (Cidade cidade : dao.read(Estados.SC)){
            System.out.println(cidade.getId()+"\t"+
                    cidade.getNome()+"\t"+
                    cidade.getEstado());
        }
        
    }
    
}
