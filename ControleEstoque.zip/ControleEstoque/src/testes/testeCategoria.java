
package testes;

import controller.daoCategoriaProduto;
import model.CategoriaProduto;

public class testeCategoria {
    public static void main(String[] args) {
        CategoriaProduto c1 = new CategoriaProduto(0, "perifericos");
        CategoriaProduto c2 = new CategoriaProduto(0, "notebooks");
        CategoriaProduto c3 = new CategoriaProduto(0, "servidores");
        //
        daoCategoriaProduto dao = new daoCategoriaProduto();
        try{
 /*
            dao.create(c1);
            dao.create(c2);
            dao.create(c3);
*/
            for (CategoriaProduto cat : dao.read()){
                System.out.println(cat.getId() + "\t" + cat.getNome());
            }
        }catch(Exception ex){
            System.out.println("ERRO: "+ex.getMessage());
        }
        
        
    }
    
}
