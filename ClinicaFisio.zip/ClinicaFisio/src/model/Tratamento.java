
package model;

import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "TRATAMENTO")

public class Tratamento {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column (name = "ID",nullable = false)
    @SwingColumn(description = "Código")
    private int id;
     @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CONSULTA", nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "ID consulta ")
    private Consulta consulta;
     @Column(name = "DATAINICIAL",nullable = false)
     @SwingColumn(description = "Data inicio")
    private LocalDate dataInicial;
    @Column(name = "DATAFINAL",nullable = false)
    @SwingColumn(description = "Data fim")
    private LocalDate dataFinal;
    @Column(name = "OBSERVACOES",nullable = false, length = 250)
    private String observacoes;
    @Column(name = "RECEITA",nullable = false, length = 50)
    private String receita;
    @Column(name = "EXAME",nullable = false, length = 50)
    private String exame;
    
    

    public Tratamento() {
    }

    public Tratamento(int id, Consulta consulta, LocalDate dataInicial, LocalDate dataFinal, String observacoes, String receita, String exame) {
        this.setId(id);
        this.setConsulta(consulta);
        this.setDataInicial(dataInicial);
        this.setDataFinal(dataFinal);
        this.setObservacoes(observacoes);
        this.setReceita(receita);
        this.setExame(exame);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setConsulta(Consulta consulta) {
        this.consulta = consulta;
    }

    public void setDataInicial(LocalDate dataInicial) {
        this.dataInicial = dataInicial==null ? LocalDate.now() : dataInicial;
    }

    public void setDataFinal(LocalDate dataFinal) {
        this.dataFinal = dataFinal==null ? LocalDate.now() : dataFinal;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes.trim().isEmpty() ? "OBSERVAÇÕES" : observacoes.toUpperCase();
    }

    public void setReceita(String receita) {
        this.receita = receita.trim().isEmpty() ? "RECEITA" : receita.toUpperCase();;
    }

    public void setExame(String exame) {
        this.exame = exame.trim().isEmpty() ? "EXAME" : exame.toUpperCase();;
    }
    

    public int getId() {
        return this.id;
    }

    public Consulta getConsulta() {
        return this.consulta;
    }

    public LocalDate getDataInicial() {
        return this.dataInicial;
    }

    public LocalDate getDataFinal() {
        return this.dataFinal;
    }

    public String getObservacoes() {
        return this.observacoes;
    }

    public String getReceita() {
        return this.receita;
    }

    public String getExame() {
        return this.exame;
    }
    

    @Override
    public String toString() {
        return observacoes;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tratamento other = (Tratamento) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
    
    
}
