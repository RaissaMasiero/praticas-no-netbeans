
package model;

import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table (name = "CONSULTA")


public class Consulta implements java.io.Serializable{
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column (name = "ID", nullable = false)
    @SwingColumn(description = "Código")
    private int id;
    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_MEDICO", nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "Medico")
    private Medico medico;
    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_PACIENTE", nullable = false,referencedColumnName = "ID")
    @SwingColumn(description = "Paciente")
    private Paciente paciente;
    @SwingColumn(description = "Data")
    @Column(name = "DATA",nullable = false)
    private LocalDate data;
    @Column(name = "HORA",nullable = false, length = 5)
    @SwingColumn(description = "Hora")
    private String hora;
    @Column(name = "SINTOMASINICIAIS",nullable = false, length = 200)
    @SwingColumn(description = "Sintomas")
    private String sintomasIniciais;

    public Consulta() {
    }

    public Consulta(int id, Medico medico, Paciente paciente, LocalDate data, String hora, String sintomasIniciais) {
        this.setId(id);
        this.setMedico(medico);
        this.setPaciente(paciente);
        this.setData(data);
        this.setHora(hora);
        this.setSintomasIniciais(sintomasIniciais);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public void setData(LocalDate data) {
        this.data = data==null ? LocalDate.now() : data;
    }

    public void setHora(String hora) {
        this.hora = hora.trim().isEmpty() ? "00:00" : hora;
    }

    public void setSintomasIniciais(String sintomasIniciais) {
        this.sintomasIniciais = sintomasIniciais.trim().isEmpty() ? "SINTOMAS PADRÃO" : sintomasIniciais.toUpperCase();;
    }

    public int getId() {
        return this.id;
    }

    public Medico getMedico() {
        return this.medico;
    }

    public Paciente getPaciente() {
        return this.paciente;
    }

    public LocalDate getData() {
        return this.data;
    }

    public String getHora() {
        return this.hora;
    }

    public String getSintomasIniciais() {
        return sintomasIniciais;
    }

    @Override
    public String toString() {
        return id+("") ;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Consulta other = (Consulta) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
    
}
