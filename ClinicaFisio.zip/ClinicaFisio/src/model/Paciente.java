
package model;

import Enum.Convenio;
import Enum.Sexo;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "PACIENTE")

public class Paciente implements java.io.Serializable{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column (name = "ID", nullable = false)
@SwingColumn(description = "Código")
private int id;
@Column (name = "NOME", nullable = false, length = 100)
@SwingColumn(description = "Nome")
private String nome;
@Column(name = "DATANASCIMENTO",nullable = false)
@SwingColumn(description = "Nascimeto")
private LocalDate dataNascimento;
@Enumerated (EnumType.STRING)
@Column(name = "SEXO",length = 2, nullable = false)
@SwingColumn(description = "Sexo")
private Sexo sexo;
@Column (name = "CPF", nullable = false, length = 14)
private String cpf;
@Column (name = "TELEFONE", nullable = false, length = 20)
private String telefone;
@Column (name = "ENDERECO", nullable = false, length = 150)
private String endereco;
@Enumerated (EnumType.STRING)
@Column(name = "CONVENIO",length = 2, nullable = false)
private Convenio convenio;


    public Paciente() {
    }

    public Paciente(int id, String nome, LocalDate dataNascimento, Sexo sexo, String cpf, String telefone, String endereco,Convenio convenio) {
        this.setId(id);
        this.setNome(nome);
        this.setDataNascimento(dataNascimento);
        this.setSexo(sexo);
        this.setCpf(cpf);
        this.setTelefone(telefone);
        this.setEndereco(endereco);
        this.setConvenio(convenio);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome.trim().isEmpty() ? "NOME PADRÃO" : nome.toUpperCase();
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento==null ? LocalDate.now() : dataNascimento;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf.trim().isEmpty() ? "000.000.000-00" : cpf;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone.trim().isEmpty() ? "(00) 0000-0000" : telefone;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco.trim().isEmpty() ? "ENDEREÇO PADRÃO" : endereco.toUpperCase();
    }

    public void setConvenio(Convenio convenio) {
        this.convenio = convenio;
    }
    

    public int getId() {
        return this.id;
    }

    public String getNome() {
        return this.nome;
    }

    public LocalDate getDataNascimento() {
        return this.dataNascimento;
    }

    public Sexo getSexo() {
        return this.sexo;
    }

    public String getCpf() {
        return this.cpf;
    }

    public String getTelefone() {
        return this.telefone;
    }

    public String getEndereco() {
        return this.endereco;
    }

    public Convenio getConvenio() {
        return this.convenio;
    }
    

    @Override
    public String toString() {
        return nome ;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Paciente other = (Paciente) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }




}
