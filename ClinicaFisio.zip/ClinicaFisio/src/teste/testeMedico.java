package teste;

import Enum.Especialidade;
import Controller.daoMedico;
import model.Medico;

public class testeMedico {

    public static void main(String[] args) {
        Medico m1 = new Medico(0, "Renata", "000/1", Especialidade.CI);

        //
        daoMedico dao = new daoMedico();
        try {

            dao.create(m1);

            for (Medico med : dao.read()) {
                System.out.println(med.getId() + "\t" + med.getNome() + "\t" + med.getCrm() + "\t" + med.getEspecialidade());
            }
        } catch (Exception ex) {
            System.out.println("ERRO: " + ex.getMessage());
        }

    }

}
