package teste;

import Controller.daoConsulta;
import Controller.daoMedico;
import Controller.daoPaciente;
import java.time.LocalDate;
import model.Consulta;
import model.Medico;
import model.Paciente;

public class testeConsulta {

    public static void main(String[] args) {
        Consulta c1 = new Consulta(0, new daoMedico().read(Medico.class, 1), new daoPaciente().read(Paciente.class, 1), LocalDate.now(), "21:00", "Sintomas");

        daoConsulta dao = new daoConsulta();
        try {

            dao.create(c1);

            for (Consulta con : dao.read()) {
                System.out.println(con.getId() + "\t" + con.getMedico() + "\t"
                        + con.getPaciente() + "\t" + con.getData() + "\t" + con.getHora() + "\t" + con.getSintomasIniciais());
            }
        } catch (Exception ex) {
            System.out.println("ERRO: " + ex.getMessage());
        }

    }

}
