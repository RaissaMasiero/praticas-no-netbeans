package teste;

import Enum.Convenio;
import Enum.Sexo;
import Controller.daoPaciente;
import java.time.LocalDate;
import model.Paciente;

public class testePaciente {

    public static void main(String[] args) {
        Paciente p1 = new Paciente(0, "Renata", LocalDate.now(), Sexo.F, "000.000.000-00", "(48)999-9999", "Criciuma", Convenio.SU);

        daoPaciente dao = new daoPaciente();
        try {

            dao.create(p1);

            for (Paciente pac : dao.read()) {
                System.out.println(pac.getId() + "\t" + pac.getNome() + "\t"
                        + pac.getDataNascimento() + "\t" + pac.getSexo() + "\t"
                        + pac.getCpf() + pac.getTelefone() + "\t"
                        + pac.getEndereco() + "\t" + pac.getConvenio());
            }
        } catch (Exception ex) {
            System.out.println("ERRO: " + ex.getMessage());
        }

    }

}
