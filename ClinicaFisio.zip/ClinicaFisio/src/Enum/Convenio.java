package Enum;

public enum Convenio {
    SU("SUS"),
    PT("Particular");

    private String descricao;

    private Convenio(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
