package Enum;

public enum Especialidade {
    EL("Eletroterapia"),
    HI("Hidroterapia"),
    CI("Cinesioterapia"),
    FR("Fisio Respiratória"),
    CR("Crioterapia");

    private String descricao;

    private Especialidade(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
