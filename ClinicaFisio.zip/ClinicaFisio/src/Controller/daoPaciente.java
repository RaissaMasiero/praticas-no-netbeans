package Controller;

import Enum.Convenio;
import Enum.Sexo;
import abstratas.dao;
import java.util.List;
import model.Medico;
import model.Paciente;

public class daoPaciente extends dao<Paciente> {

    public List<Paciente> read() {
        return super.read("select p from Paciente p order by p.nome");
    }

    public List<Paciente> read(String filtro) {
        return super.read(
                "select p from Paciente p where p.nome like ?1 order by p.nome",
                "%" + filtro.toUpperCase() + "%");

    }
    public List<Paciente> read(Sexo sexo){
        return super.read("select p from Paciente p where p.sexo = ?1 order by p.nome", sexo);    
    }
    
    public List<Paciente> read(Convenio convenio){
        return super.read("select p from Paciente p where p.convenio = ?1 order by c.nome", convenio);    
    }
}
