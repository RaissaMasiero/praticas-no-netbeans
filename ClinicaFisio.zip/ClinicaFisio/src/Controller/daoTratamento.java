package Controller;

import abstratas.dao;
import java.util.List;
import model.Tratamento;

public class daoTratamento extends dao<Tratamento> {

    public List<Tratamento> read() {
        return super.read("select t from Tratamento t order by t.observacoes");
    }

    public List<Tratamento> read(String filtro) {
        return super.read(
                "select t from Tratamento t where t.observacoes like ?1 order by t.observacoes",
                "%" + filtro.toUpperCase() + "%");

    }

}
