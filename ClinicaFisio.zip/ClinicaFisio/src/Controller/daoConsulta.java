package Controller;

import abstratas.dao;
import java.util.List;
import model.Consulta;

public class daoConsulta extends dao<Consulta> {

    public List<Consulta> read() {
        return super.read("select c from Consulta c order by c.data");
    }

    public List<Consulta> read(String filtro) {
        return super.read("select c from Consulta c where c.sintomasiniciais like ?1 order by c.data",
                "%" + filtro.toUpperCase() + "%");
    }

}
