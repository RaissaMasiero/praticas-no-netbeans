package  Controller;
import abstratas.dao;
import java.util.List;
import model.Medico;

public class daoMedico extends dao<Medico> {

    public List<Medico> read() {
        return super.read("select m from Medico m order by m.nome");
    }

    public List<Medico> read(String filtro) {
        return super.read(
                "select m from Medico m where m.nome like ?1 order by m.nome",
                "%" + filtro.toUpperCase() + "%");

    }
}
