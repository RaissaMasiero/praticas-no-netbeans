
package controller;

import abstratas.dao;
import java.sql.SQLException;
import model.Cliente;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class daoCliente extends dao{
    public int create(Cliente cliente) throws SQLException{
        String SQL="INSERT INTO CLIENTE (NOME,ENDERECO,CPF,ID_CIDADE) VALUES (?,?,?,?)";
        return super.executeUpdate(SQL, 
                cliente.getNome(),
                cliente.getEndereco(),
                cliente.getCpf(),
                cliente.getCidade().getId()
                );
        
    }
    public int update(Cliente cliente) throws SQLException{
        String SQL="UPDATE CLIENTE SET NOME=?,ENDERECO=?,CPF=?,ID_CIDADE=? WHERE ID=?";
        return super.executeUpdate(SQL, 
                cliente.getNome(),
                cliente.getEndereco(),
                cliente.getCpf(),
                cliente.getCidade().getId(),
                cliente.getId()
                );
    }
    public int delete(Cliente cliente) throws SQLException{
        return super.executeUpdate(
        "DELETE FROM CLIENTE WHERE ID="+cliente.getId()
        );
    }
    public Cliente read(int id) throws SQLException{
        ResultSet rs = super.executeQuery("SELECT * FROM CLIENTE WHERE ID="+id);
        return (rs.next() ? createObject(rs) : null);
    }
    public List<Cliente> read() throws SQLException{
        ResultSet rs = super.executeQuery("SELECT * FROM CLIENTE ORDER BY CLIENTE.NOME");
        List<Cliente> retorno = new LinkedList<>();
        while (rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;        
    }
    public List<Cliente> read(String filtro) throws SQLException{
        ResultSet rs = super.executeQuery(
        "SELECT * FROM CLIENTE WHERE CLIENTE.NOME LIKE ? ORDER BY CLIENTE.NOME",
        "%"+filtro.toUpperCase()+"%");
        List<Cliente> retorno = new LinkedList<>();
        while (rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;        
    }    
    private Cliente createObject(ResultSet rs) throws SQLException{
        return new Cliente(
                rs.getInt("ID"), 
                rs.getString("NOME"), 
                rs.getString("ENDERECO"), 
                new daoCidade().read(rs.getInt("ID_CIDADE")), 
                rs.getString("CPF"));
    }
}
