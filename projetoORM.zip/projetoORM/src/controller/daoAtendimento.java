
package controller;

import abstratas.dao;
import enums.Status;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import model.Atendimento;

public class daoAtendimento extends dao{
    public int create(Atendimento atendimento) throws SQLException{
        String SQL="INSERT INTO ATENDIMENTO (DATA,DESCRICAO,ID_TECNICO,ID_CLIENTE,STATUS) VALUES (?,?,?,?,?)";
        return super.executeUpdate(SQL, 
                atendimento.getData(),
                atendimento.getDescricao(),
                atendimento.getTecnico().getId(),
                atendimento.getCliente().getId(),
                atendimento.getStatus().name()
                );
    }
    public int update(Atendimento atendimento) throws SQLException{
        String SQL="UPDATE ATENDIMENTO SET DATA=?,DESCRICAO=?,ID_TECNICO=?,"
                + "ID_CLIENTE=?,STATUS=? WHERE ID=?";
        return super.executeUpdate(SQL, 
                atendimento.getData(),
                atendimento.getDescricao(),
                atendimento.getTecnico().getId(),
                atendimento.getCliente().getId(),
                atendimento.getStatus().name(),
                atendimento.getId()
                );
    }
    public int delete(Atendimento atendimento) throws SQLException{
        return super.executeUpdate("DELETE FROM ATENDIMENTO WHERE ID="+atendimento.getId());
    }
    public Atendimento read(int id) throws SQLException{
        String SQL="SELECT * FROM ATENDIMENTO WHERE ID="+id;
        ResultSet rs = super.executeQuery(SQL);
        return (rs.next() ? this.createObject(rs) : null);
    }
    public List<Atendimento> read() throws SQLException{
        String SQL = "SELECT * FROM ATENDIMENTO ORDER BY DATA";
        ResultSet rs = super.executeQuery(SQL);
        List<Atendimento> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
    private Atendimento createObject(ResultSet rs) throws SQLException{
        return new Atendimento(
                rs.getInt("ID"), 
                rs.getDate("DATA").toLocalDate(), 
                new daoCliente().read(rs.getInt("ID_CLIENTE")), 
                new daoTecnico().read(rs.getInt("ID_TECNICO")), 
                rs.getString("DESCRICAO"), 
                Status.valueOf(rs.getString("STATUS"))
        );
    }
    
}
