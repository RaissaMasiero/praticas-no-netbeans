
package controller;

import abstratas.dao;
import model.Tecnico;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class daoTecnico extends dao{
    public int create(Tecnico tecnico) throws SQLException{
        String SQL="INSERT INTO TECNICO(NOME) VALUES (?)";
        return super.executeUpdate(SQL, tecnico.getNome());        
    }
    public int update(Tecnico tecnico) throws SQLException{
        String SQL="UPDATE TECNICO SET NOME=? WHERE ID=?";
        return super.executeUpdate(SQL,tecnico.getNome(),
                                       tecnico.getId());
    }
    public int delete(Tecnico tecnico) throws SQLException{
        return super.executeUpdate("DELETE FROM TECNICO WHERE ID="+tecnico.getId());
    }
    public Tecnico read(int id) throws SQLException{
        String SQL="SELECT * FROM TECNICO WHERE ID="+id;
        ResultSet rs = super.executeQuery(SQL);
        return(rs.next() ? createObject(rs) : null);
    }
    public List<Tecnico> read() throws SQLException{
        String SQL="SELECT * FROM TECNICO ORDER BY NOME";
        ResultSet rs = super.executeQuery(SQL);
        List<Tecnico> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }    
    public List<Tecnico> read(String filtro) throws SQLException{
        String SQL="SELECT * FROM TECNICO WHERE NOME LIKE ? ORDER BY NOME";
        ResultSet rs = super.executeQuery(SQL,"%"+filtro.toUpperCase()+"%");
        List<Tecnico> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }    
    private Tecnico createObject(ResultSet rs) throws SQLException{
        return (new Tecnico(
                rs.getInt("ID"), 
                rs.getString("NOME")));
    }
    
}
