
package enums;

public enum Status {
    A("Aberto"),
    F("Finalizado"),
    E("Em Espera");
    //
    private String descricao;
    //
    private Status(String descricao) {
        this.descricao = descricao;
    }
    //
    @Override
    public String toString() {
        return descricao;
    }
}
