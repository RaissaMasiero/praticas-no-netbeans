
package model;

import abstratas.Base;

public class Cliente extends Base{
    private String endereco;
    private String cpf;
    private Cidade cidade;

    //
    public Cliente(){
        super();
        this.setEndereco("");
        this.setCpf("");
        this.setCidade(null);     
    }
    public Cliente(int id,String nome,String endereco,Cidade cidade,String cpf){
        super(id, nome);
        this.setEndereco(endereco);
        this.setCpf(cpf);
        this.setCidade(cidade);     
    }
    //
    public void setEndereco(String endereco) {
        this.endereco = endereco.trim().isEmpty()?"ENDEREÇO":endereco.toUpperCase();
    }
    public void setCidade(Cidade cidade) {
        this.cidade = cidade==null ? new Cidade() : cidade;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf.trim().isEmpty()?"000.000.000-00":cpf;
    }
    public String getEndereco() {
        return this.endereco;
    }
    public Cidade getCidade() {
        return this.cidade;
    }

    public String getCpf() {
        return this.cpf;
    }
}
