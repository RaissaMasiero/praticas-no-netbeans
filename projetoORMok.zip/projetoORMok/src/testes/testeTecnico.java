
package testes;

import controller.daoTecnico;
import java.sql.SQLException;
import model.Tecnico;

public class testeTecnico {
    public static void main(String[] args) {
        daoTecnico dao = new daoTecnico();
        try{
            for(Tecnico tecnico : dao.read()){
                System.out.println(tecnico.getId()+"\t"+tecnico.getNome());
            }
        }catch(SQLException ex){
            System.out.println("ERRO:"+ex.getMessage());
        }
    
    }
    
}
