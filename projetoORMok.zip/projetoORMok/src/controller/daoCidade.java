
package controller;

import abstratas.dao;
import enums.Estados;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;
import model.Cidade;

public class daoCidade extends dao{
    public int create(Cidade cidade) throws SQLException{
        String SQL="INSERT INTO CIDADE(NOME,SIGLA) VALUES (?,?)";
        return super.executeUpdate(SQL, cidade.getNome(),
                                        cidade.getEstado().name());
    }
    public int update(Cidade cidade) throws SQLException{
        String SQL="UPDATE CIDADE SET NOME=?, SIGLA=? WHERE ID=?";
        return super.executeUpdate(SQL, cidade.getNome(),
                                        cidade.getEstado().name(),
                                        cidade.getId());
    }    
    public int delete(Cidade cidade) throws SQLException{
        String SQL="DELETE FROM CIDADE WHERE ID="+cidade.getId();
        return super.executeUpdate(SQL);
    }
    public Cidade read(int id) throws SQLException{
        String SQL="SELECT * FROM CIDADE WHERE ID="+id;
        ResultSet rs = super.executeQuery(SQL);
        return (rs.next() ? createObject(rs) : null);
    }
    public List<Cidade> read() throws SQLException{
        String SQL="SELECT * FROM CIDADE ORDER BY CIDADE.NOME";
        ResultSet rs = super.executeQuery(SQL);
        List<Cidade> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;
    }
    public List<Cidade> read(String filtro) throws SQLException{
        String SQL="SELECT * FROM CIDADE WHERE CIDADE.NOME LIKE ? ORDER BY CIDADE.NOME";
        ResultSet rs = super.executeQuery(SQL,"%"+filtro.toUpperCase()+"%");
        List<Cidade> retorno = new LinkedList<>();
        while(rs.next()){
            retorno.add(createObject(rs));
        }
        return retorno;       
    }
    
    private Cidade createObject(ResultSet rs) throws SQLException{
        return (
                new Cidade(
                        rs.getInt("ID"), 
                        rs.getString("NOME"), 
                        Estados.valueOf(rs.getString("SIGLA")))
                );
    }
}

