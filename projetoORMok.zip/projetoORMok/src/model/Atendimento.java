
package model;

import enums.Status;
import java.time.LocalDate;

public class Atendimento implements java.io.Serializable{
    @SwingColumn(description = "Código")
    private int id;
    @SwingColumn(description = "Data")
    private LocalDate data;
    @SwingColumn(description = "Cliente")
    private Cliente cliente;
    private Tecnico tecnico;
    @SwingColumn(description = "Descrição")
    private String descricao;
    @SwingColumn(description = "Status")
    private Status status;
    //
    public Atendimento(){
        this.setId(0);
        this.setData(null);
        this.setCliente(null);
        this.setTecnico(null);
        this.setDescricao("");
        this.setStatus(Status.A);
    }
    public Atendimento(int id,LocalDate data,
            Cliente cliente,Tecnico tecnico,
            String descricao, Status status){
        this.setId(id);
        this.setData(data);
        this.setCliente(cliente);
        this.setTecnico(tecnico);
        this.setDescricao(descricao);
        this.setStatus(status);        
    }
    //
    public void setId(int id) {
        this.id = id;
    }
    public void setData(LocalDate data) {
        this.data = data==null ? LocalDate.now() : data;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente==null?new Cliente():cliente;
    }
    public void setTecnico(Tecnico tecnico) {
        this.tecnico = tecnico==null?new Tecnico():tecnico;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao.trim().isEmpty()?"DESCRIÇÃO":
                descricao.toUpperCase();
    }
    public void setStatus(Status status) {
        this.status = status;
    }
    public int getId() {
        return this.id;
    }
    public LocalDate getData() {
        return this.data;
    }
    public Cliente getCliente() {
        return this.cliente;
    }
    public Tecnico getTecnico() {
        return this.tecnico;
    }
    public String getDescricao() {
        return this.descricao;
    }
    public Status getStatus() {
        return this.status;
    }
    //
    public String toString(){
        return (this.data+"->"+this.cliente+"->"+this.status);
    }
    //
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + this.id;
        return hash;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Atendimento other = (Atendimento) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
}
