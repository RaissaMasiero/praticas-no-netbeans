
package model;

import abstratas.Base;

public class Tecnico extends Base{
    public Tecnico(){
        super();
    }
    public Tecnico(int id,String nome){
        super(id, nome);
    }
}
