
package model;

import enums.Tipos;

public class Equipamento implements java.io.Serializable{
    private int id;
    private String descricao;
    private Tipos tipo;
    private double valor;
    //

    public Equipamento() {
        this.setId(0);
        this.setDescricao("padrão");
        this.setTipo(Tipos.D);
        this.setValor(0);
    }

    public Equipamento(int id, String descricao, Tipos tipo, double valor) {
        this.setId(id);
        this.setDescricao(descricao);
        this.setTipo(tipo);
        this.setValor(valor);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao.trim().isEmpty()?"PADRÃO":descricao.toUpperCase();
    }

    public void setTipo(Tipos tipo) {
        this.tipo = tipo;
    }

    public void setValor(double valor) {
        this.valor = valor <= 0 ? 0.01 : valor;
    }

    public int getId() {
        return this.id;
    }

    public String getDescricao() {
        return this.descricao;
    }

    public Tipos getTipo() {
        return this.tipo;
    }

    public double getValor() {
        return this.valor;
    }

    @Override
    public String toString() {
        return this.descricao;
    }
    
}
