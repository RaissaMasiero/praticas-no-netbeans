
package model;

import abstratas.Base;
import enums.Estados;

public class Cidade extends Base{
    private Estados estado;
    //
    public Cidade(){
        super();
        this.setEstado(Estados.SC);
    }
    public Cidade(int id,String nome,Estados estado){
        super(id, nome);
        this.setEstado(estado);
    }
    //
    public Estados getEstado() {
        return this.estado;
    }
    public void setEstado(Estados estado) {
        this.estado = estado;
    }
}
