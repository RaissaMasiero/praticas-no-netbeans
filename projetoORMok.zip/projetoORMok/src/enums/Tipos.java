
package enums;

public enum Tipos {
   I("IMPRESSORA"), 
   N("NOTEBOOK"), 
   S("SERVIDOR"), 
   D("DESKTOP");
   
   private String descricao;

    private Tipos(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
